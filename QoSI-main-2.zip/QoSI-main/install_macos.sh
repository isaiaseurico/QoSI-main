#!/bin/sh

brew install iperf3
brew install python
pip3 install iperf3 icmplib requests
